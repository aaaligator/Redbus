package com.cg.naukriregis.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RedBusBookingPage {

	@FindBy(how=How.ID,id="src")
	WebElement source;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"search\"]/div/div[1]/div/ul/li[1]")
	WebElement pune;
	
	@FindBy(how=How.ID,id="dest")
	WebElement destination;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"search\"]/div/div[2]/div/ul/li[1]")
	WebElement mumbai;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[4]/td[2]")
	WebElement date;
	@FindBy(how=How.ID,id="search_btn")
    WebElement search;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"8194310\"]/div/div[2]/div[1]")
	WebElement viewSeats;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"8194310\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div/div[1]/ul/li[1]/span[2]/div")
	WebElement boardingPt;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"8194310\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div/div[2]/ul/li[1]/span[2]")
	WebElement droppingPt;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"8194310\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/div[6]/button")
	WebElement proceed;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"seatno-04\"]")
	WebElement name;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"root\"]/div/div[4]/div/div/div[1]/div[1]/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div/span[1]/label")
	WebElement gender;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"seatno-01\"]")
	WebElement age;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"seatno-05\"]")
	WebElement email;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"seatno-06\"]")
	WebElement number;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"root\"]/div/div[4]/div/div/div[2]/div[2]/input")
	WebElement p2p;
	
	public RedBusBookingPage() {
	}

	public String getSource() {
		return this.source.getAttribute("value");
	}

	public void setSource(String source) {
		this.source.sendKeys(source);
	}

	public String getDestination() {
		return this.destination.getAttribute("value");
	}

	public void setDestination(String destination) {
		this.destination.sendKeys(destination);
	}

	public String getDate() {
		return this.date.getAttribute("value");
	}

	public void setDate() {
		date.click();
	}

	public String getSearch() {
		return this.search.getAttribute("value");
	}

	public void setSearch() {
		search.click();
	}

	public String getViewSeats() {
		return this.viewSeats.getAttribute("value");
	}

	public void setViewSeats() {
		viewSeats.click();
	}

	public String getBoardingPt() {
		return this.boardingPt.getAttribute("value");
	}

	public void setBoardingPt() {
		boardingPt.click();
	}

	public String getDroppingPt() {
		return this.droppingPt.getAttribute("value");
	}

	public void setDroppingPt() {
		droppingPt.click();
	}

	public String getName() {
		return this.name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getGender() {
		return this.gender.getAttribute("value");
	}

	public void setGender() {
		gender.click();
	}

	public String getAge() {
		return this.age.getAttribute("value");
	}

	public void setAge(String age) {
		this.age.sendKeys(age);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getNumber() {
		return this.number.getAttribute("value");
	}

	public void setNumber(String number) {
		this.number.sendKeys(number);
	}

	public String getP2p() {
		return this.p2p.getAttribute("value");
	}

	public void setP2p() {
		p2p.click();
	}

	public String getProceed() {
		return this.proceed.getAttribute("value");
	}

	public void setProceed() {
		proceed.click();
	}

	public String getPune() {
		return this.pune.getAttribute("value");
	}

	public void setPune() {
		pune.click();
	}

	public String getMumbai() {
		return this.mumbai.getAttribute("value");
	}

	public void setMumbai() {
		mumbai.click();
	}
	
	
	 
}
